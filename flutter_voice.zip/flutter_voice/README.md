# Flutter Speech to Text App Tutorial | Voice Recognition

[YouTube Tutorial](https://youtu.be/wDWoD1AaLu8)